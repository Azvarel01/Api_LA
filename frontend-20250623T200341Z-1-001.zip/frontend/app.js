const apiURL = "http://localhost:8000/clientes/";

document.getElementById("clienteForm").addEventListener("submit", function (e) {
  e.preventDefault();
  const nombre = document.getElementById("nombre").value;
  const correo = document.getElementById("correo").value;

  const nuevoCliente = { nombre, correo };

  fetch(apiURL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify(nuevoCliente)
  })
    .then(res => {
      if (!res.ok) throw new Error("Error al crear cliente");
      return res.json();
    })
    .then(() => {
      document.getElementById("clienteForm").reset();
      cargarClientes();
    })
    .catch(error => console.error(error));
});

function cargarClientes() {
  fetch(apiURL)
    .then(res => res.json())
    .then(clientes => {
      const contenedor = document.getElementById("clientes");
      contenedor.innerHTML = "";
      clientes.forEach(cliente => {
        const div = document.createElement("div");
        div.classList.add("cliente");
        div.innerHTML = `
          <strong>${cliente.nombre}</strong>
          <span>${cliente.correo}</span>
          <div class="acciones">
            <button onclick="editarCliente(${cliente.id_usuario}, '${cliente.nombre}', '${cliente.correo}')">Editar</button>
            <button class="delete" onclick="eliminarCliente(${cliente.id_usuario})">Eliminar</button>
          </div>
        `;
        contenedor.appendChild(div);
      });
    })
    .catch(error => console.error("Error al cargar clientes:", error));
}

function eliminarCliente(id) {
  if (!confirm("¿Seguro que deseas eliminar este cliente?")) return;

  fetch(`${apiURL}${id}`, {
    method: "DELETE"
  })
    .then(res => {
      if (!res.ok) throw new Error("Error al eliminar cliente");
      cargarClientes();
    })
    .catch(error => console.error(error));
}

function editarCliente(id, nombreActual, correoActual) {
  const nuevoNombre = prompt("Editar nombre:", nombreActual);
  const nuevoCorreo = prompt("Editar correo:", correoActual);

  if (nuevoNombre && nuevoCorreo) {
    fetch(`${apiURL}${id}`, {
      method: "PUT",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify({ nombre: nuevoNombre, correo: nuevoCorreo })
    })
      .then(res => {
        if (!res.ok) throw new Error("Error al editar cliente");
        return res.json();
      })
      .then(() => {
        cargarClientes();
      })
      .catch(error => console.error(error));
  }
}

// Mostrar los clientes al cargar la página
cargarClientes();
