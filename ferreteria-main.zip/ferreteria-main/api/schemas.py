from pydantic import BaseModel

class ClienteBase(BaseModel):
    nombre: str
    correo: str

class ClienteCreate(ClienteBase):
    pass

class ClienteOut(ClienteBase):
    id_usuario: int

    class Config:
        orm_mode = True


class ClienteUpdate(ClienteBase):
    nombre: str | None = None
    correo: str | None = None
    
class ProveedorBase(BaseModel):
    nombre: str
    correo: str
class ProveedorCreate(ProveedorBase):
    pass
class ProveedorOut(ProveedorBase):
    id_proveedor: int

    class Config:
        orm_mode = True
        
