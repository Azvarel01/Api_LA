from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from api.routes import router
from sqlmodel import SQLModel
from api.database import engine

def create_app():
    app = FastAPI()

    # Aquí creamos las tablas con SQLModel
    SQLModel.metadata.create_all(bind=engine)

    origins = [
        "http://localhost",
        "http://localhost:3000",
        "http://localhost:8000",
        "http://localhost:8080",
    ]

    app.add_middleware(
        CORSMiddleware,
        allow_origins=origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    app.include_router(router)
    return app

