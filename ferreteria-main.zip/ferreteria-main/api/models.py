from sqlmodel import SQLModel, Field
from typing import Optional

class Cliente(SQLModel, table=True):
    id_usuario: Optional[int] = Field(default=None, primary_key=True)
    nombre: str
    correo: str
    
class Proveedor(SQLModel, table=True):
    id_proveedor: int = Field(default=None, primary_key=True)
    nombre: str = Field()
    correo: str = Field()
