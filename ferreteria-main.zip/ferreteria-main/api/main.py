from api.create__app import create_app

app = create_app()
