from fastapi import APIRouter,Depends,HTTPException
from sqlmodel import Session, select
from api.models import Cliente,Proveedor
from api.schemas import ClienteCreate,ProveedorCreate,ClienteOut,ClienteUpdate
from api.database import get_session


router=APIRouter()

@router.get("/clientes/", response_model=list[ClienteOut])
def obtener_clientes(session: Session = Depends(get_session)):
    statement = select(Cliente)
    clientes = session.exec(statement).all()
    return clientes

@router.get("/clientes/{id_usuario}", response_model=ClienteOut)
def obtener_cliente_por_id(id_usuario: int, session: Session = Depends(get_session)):
    cliente = session.get(Cliente, id_usuario)
    if not cliente:
        raise HTTPException(status_code=404, detail="Cliente no encontrado")
    return cliente  

@router.put("/clientes/{id_usuario}",response_model=ClienteOut)
def actualizar_cliente(
    id_usuario: int, 
    cliente: Cliente,
    session: Session = Depends(get_session)):
    cliente_db=session.get(Cliente, id_usuario)
    if not cliente_db:
        raise HTTPException(status_code=404, detail="Cliente no encontrado")
    cliente_db.nombre = cliente.nombre
    cliente_db.correo = cliente.correo
    session.add(cliente_db)
    session.commit()
    session.refresh(cliente_db)
    return cliente_db


@router.patch("/clientes/{id_usuario}", response_model=ClienteOut)
def actualizar_cliente_parcial(     
    id_usuario: int, 
    cliente: ClienteUpdate,
    session: Session = Depends(get_session)):
    cliente_db = session.get(Cliente, id_usuario)
    if not cliente_db:
        raise HTTPException(status_code=404, detail="Cliente no encontrado")
    
    if cliente.nombre is not None:
        cliente_db.nombre = cliente.nombre
    if cliente.correo is not None:
        cliente_db.correo = cliente.correo
    
    session.add(cliente_db)
    session.commit()
    session.refresh(cliente_db)
    return cliente_db

@router.delete("/clientes/{id_usuario}")
def eliminar_cliente(id_usuario: int, session: Session = Depends(get_session)):
    cliente = session.get(Cliente, id_usuario)
    if not cliente:
        raise HTTPException(status_code=404, detail="Cliente no encontrado")
    session.delete(cliente)
    session.commit()
    return {"detail": "Cliente eliminado exitosamente"}

@router.get("/proveedores/")
def obtener_proveedores(session:Session =Depends(get_session)):
    statement=select(Proveedor)
    proveedor=session.exec(statement).all()
    return proveedor



    


@router.get("/proveedores/{id_proveedor}")
def obtener_proveedor_por_id(id_proveedor: int, session: Session = Depends(get_session)):
    proveedor = session.get(Proveedor, id_proveedor)
    if not proveedor:
        raise HTTPException(status_code=404, detail="Proveedor no encontrado")
    return proveedor

@router.post("/proveedores/")
def crear_proveedor(proveedor:Proveedor, session:Session =Depends(get_session)):
    session.add(proveedor)
    session.commit()
    session.refresh(proveedor)
    return proveedor

